# Japanese Resources

> A collection of Japanese learning resources meant to help you learn through immersion, see [here](https://donkuri.github.io/learn-japanese/guide/) for an explanation. A lot of these resources come from the [various resource aggregators](#resource-aggregators) on here, as well as the `#resources-sharing` channel on the [TMW](https://learnjapanese.moe/) Discord server.

If you are interested in contributing, **make a pull request**.

- [Learning guides](#learning-guides)
- [Hiragana and Katakana](#hiragana-and-katakana)
- [Anki and Yomitan](#anki-and-yomitan)
- [Kanji](#kanji)
- [Vocabulary](#vocabulary)
- [Grammar](#grammar)
- [Mining](#mining)
- [Immersion](#immersion)
- [Listening](#listening)
- [Writing](#writing)
- [Output](#output)
- [Resource Aggregators](#resource-aggregators)
- [Miscellaneous](#miscellaneous)


## Learning guides

This section is dedicated to Japanese learning guides. Start here unless you know what you're doing.

- [Immersion-Based Japanese Learning](https://donkuri.github.io/learn-japanese/guide/) - Frequently updated guide introducing everything you need in order to learn Japanese. Written by [kuri](https://github.com/donkuri/).
- [TMW's guide to learning Japanese](https://learnjapanese.moe/guide/) - Fantastic guide that has helped thousands learn Japanese using immersion. Written by shoui.

## Hiragana and Katakana

Hiragana and katakana (commonly called *kana* together) form two basic alphabets used in Japanese. You may or may not want to learn how to write them, but at the very least you will need to be able to recognize and read them.

- Memorizing the kana
  - **[Kuuube's kana learning game](https://kuuuube.github.io/kana-quiz/)** - Simple and clean. Great way to learn kana. See the [audio version](https://kuuuube.github.io/kana-quiz/kana/) as well.
  - [Ved's kana learning game](https://vedxyz.github.io/kana/) - This one has a few more explanations.
  - [Tofugu's hiragana guide](https://www.tofugu.com/japanese/learn-hiragana/) - Another approach to learning hiragana with mnemonics.

- Writing the kana
  - [Takumi's hiragana writing guide](https://www.youtube.com/watch?v=wD3FJgij79c) - Learn how to write hiragana (if you want to).
  - [Takumi's katakana writing guide](https://www.youtube.com/watch?v=rf-n_qI2occ) - The same but for katakana.

- Hentaigana
  - [Kuuube's Hentaigana Input](https://github.com/Kuuuube/hentaigana_input) - A way to input archaic (so-called 'hentaigana') characters.

## Anki and Yomitan

These two tools form the backbone of the current immersion-based Japanese learning community. As such, they deserve a special section.

- [Anki](https://apps.ankiweb.net/) - A [spaced-repetition system](https://en.wikipedia.org/wiki/Spaced_repetition) used to memorize things, mostly vocabulary.
  - **[Anki manual](https://docs.ankiweb.net/#/)** - The official docs for Anki. You are encouraged to read at least [this](https://docs.ankiweb.net/getting-started.html). For an explanation of how FSRS (an important Anki algorithm) works, you can see this [tutorial and FAQ](https://github.com/open-spaced-repetition/fsrs4anki/blob/main/docs/tutorial.md).
  - **[Anki setup guide](https://donkuri.github.io/learn-japanese/setup/#anki-setup)** - A guide explaining how to setup Anki as well as what it is. Written by [kuri](https://github.com/donkuri/).
  - [Xelieu's Anki setup](https://lazyguidejp.github.io/jp-lazy-guide/) - Another setup guide for Anki. Written by [Xelieu](https://github.com/xelieu).
  - [Anki Templates](https://chrisk91.me/post/2018-09-28-Anki-Templates-Introduction-HTML/) - A handy guide explaining Anki card formatting.
  - [backfill-anki-yomitan](https://github.com/Manhhao/backfill-anki-yomitan) - An amazing new add-on that allows us to backfill various fields in Anki through Yomitan's API.

- [Yomitan](https://yomitan.wiki/) - A pop-up dictionary browser extension that lets you analyze words and grammar on the fly.
  - **[Yomitan setup guide](https://donkuri.github.io/learn-japanese/setup/#yomitan-setup)** - A guide explaining how to setup Yomitan as well as what it is. Written by [kuri](https://github.com/donkuri/).
  - [Xelieu's Yomitan setup](https://xelieu.github.io/jp-lazy-guide/setupYomitanOnPC/) - Another setup guide for Yomitan. Written by [Xelieu](https://github.com/xelieu).
  - [Xelieu's Yomitan on Android setup](https://xelieu.github.io/jp-lazy-guide/setupYomitanOnAndroid/) - A setup guide for Yomitan on Android devices. Written by [Xelieu](https://github.com/xelieu).
  - [QM's Yomitan Audio](https://animecards.site/yomitan_audio/) - A fantastic new tool to help you get accurate audio on Yomitan whenever possible.
  - **[Marv's dictionary collection](https://github.com/MarvNC/yomitan-dictionaries)** - A collection of Yomitan dictionaries hosted by [MarvNC](https://github.com/MarvNC).

- Miscellaneous
  - [Marv's JP-Resources](https://github.com/MarvNC/JP-Resources) - Very handy collection of resources and tools written by [MarvNC](https://github.com/MarvNC).
  - [JPDB](https://jpdb.io/) - A good alternative to Anki if you do not like it for some reason. If you decide to use JPDB, read [this guide](https://docs.google.com/document/d/1UaukDdykpYXGFR37VhOaXK9NNGNGqxob7bNYSQQP6aI/edit?tab=t.0#heading=h.hpr0a6syyr08) and consider using [this](https://github.com/max-kamps/jpd-breader) and [this](https://github.com/Kagu-chan/jpdb.io).

## Kanji

Various resources for kanji. **If you're wondering whether you should do isolated kanji study, please [read this article on it](https://donkuri.github.io/learn-japanese/guide/#on-the-topic-of-isolated-kanji-study)**.

- Mnemonics
  - [RRTK450](https://mega.nz/file/2SJiWC4b#hL98qtC_hiLlQDg0LqVJoqD2-5ywT2Nwd4kjROY_KwQ) - A shortened "recognition" version of [RTK](https://www.amazon.com/Remembering-Kanji-Complete-Japanese-Characters/dp/0824835921). **Disclaimer: The stories were taken from a website and some of them are pretty offensive.**
  - [Kodansha Kanji Learner's Course](https://www.amazon.com/Kodansha-Kanji-Learners-Course-Step/dp/1568365268) - An arguably better version of Remembering the Kanji. Has [an accompanying Anki deck](https://ankiweb.net/shared/info/1564742924)

- Phonetics
  - [Usagichan Kanji Phonetics](https://drive.google.com/file/d/1xyynMQiOuqlC_cBBTwG9t3snRubHqU7e/view?usp=drive_link) - An Anki deck meant to help you learn phonetic radicals.
  - [Kanji Code](https://thekanjicode.com/) - A kanji phonetics book based on the PhD dissertation of the author. There is a [companion Anki deck](https://ankiweb.net/shared/info/470563167).

- Search tools
  - [Kanji Punt Gun](https://kuuuube.github.io/kanji-puntgun/) - Pretty complete kanji search tool based on both components and radicals.
  - [wareya](http://kanji.wareya.moe/) - Another search tool based on kanji composition.

- Miscellaneous
  - [Kuuube Kanji Grid](https://ankiweb.net/shared/info/1610304449) - A very useful add-on that lets you see how many kanji you've learned in Anki.
  - [Kanji Schizo](https://github.com/kaanium/new-kanji-finder) - This Python script lets you find new kanji in `.epub` or subtitle files.
  - [四字熟語](https://drive.proton.me/urls/86STV4PWGC#Em1G6QVxoLhv) - A newer 四字熟語 deck.
  - [漢字でGO!](https://plicy.net/GamePlay/155561) - A fantastic game quizzing you about word readings. Can get really tough.
  - [漢字テスト](https://www.gamedesign.jp/sp/kanji/) - A test to see what words you can read.

## Vocabulary

Vocabulary refers to words, not kanji directly. Words are usually made up of kanji and one shouldn't confuse the two. As it is recommended to do a mining deck after learning basic vocabulary, there's only a single recommended resource.

- **[Kaishi 1.5k](https://github.com/donkuri/Kaishi/)** - The recommended beginner vocabulary Anki deck. Latest release found [here](https://github.com/donkuri/Kaishi/releases) and [here](https://ankiweb.net/shared/info/1196762551).

## Grammar

Grammar is the glue that holds together words in Japanese.

- Guides
  - **[Yokubi](https://yoku.bi/)** - A short and to the point grammar guide introducing the basics. Adapted from [Sakubi](https://sakubi.neocities.org/) by [Morg](https://morg.systems/).
  - [IMABI](https://imabi.org/) - Extremely comprehensive look at Japanese grammar, from the basics all the way to Classical Japanese.
  - [Tae Kim](https://guidetojapanese.org/learn/category/grammar-guide/grammar-start/) - A slightly older guide that introduces grammar in a casual manner.

- Specific grammar points
  - [コノム's guide to は and が](https://konomu.github.io/wa-ga-basics) - A well-written guide explaining one of the most complex grammar point in Japanese.

- Anki decks
  - **[NihongoKyoshi deck](https://drive.google.com/file/d/1tDBaabwgZMO8nxkcwcw4qBXayuk_513T/view)** - Monolingual deck based on [NihongoKyoshi](https://nihongokyoshi-net.com/).
  - [DOJG deck](https://dojgdeck.neocities.org/) - Based on the famous [Dictionary of Japanese Grammar series](https://www.amazon.com/Dictionary-Basic-Japanese-Grammar/dp/4789004546). See [this](https://djtguide.github.io/grammar/dojgmain.html) and [this](https://github.com/aiko-tanaka/Grammar-Dictionaries) also.
  - [Bunpro deck](https://mega.nz/file/pZQUxLJB#uRuBfWzkCgwlunKc0kGS0YuMkeOLbbGeDJvntkBh_DE) - An anki deck made from [Bunpro](https://bunpro.jp/), a popular grammar app.

- YouTube videos
  - [Japanese Ammo with Misa](https://www.youtube.com/@JapaneseAmmowithMisa) - A popular channel explaining basic grammar points.
  - [Game Gengo](https://www.youtube.com/c/GameGengo) - Another channel explaining Japanese grammar but through video games.
  - [Cure Dolly](https://www.youtube.com/playlist?list=PLg9uYxuZf8x_A-vcqqyOFZu06WlhnypWj) - A popular series of video on Japanese grammar. Transcript [here](https://docs.google.com/document/d/1XpuXerkGU8waJ4DPDNJA4bGeqOvM-csXjTe57iHARHc/edit).
  - [Visualizing Japanese Grammar](https://www2.gwu.edu/~eall/vjgnew/vjghomepage/vjghome.htm) - An older but still popular series on Japanese grammar.
  - [国語文法](https://www.youtube.com/playlist?list=PLKRhhk0lEyzM-XOmo9F55BoRlPSSivcVd) - Japanese grammar as it is presented in Japanese schools.

- Monolingual resources
  - **[初級を教える人のための日本語文法ハンドブック](https://www.3anet.co.jp/np/books/4680/)** - Fantastic Japanese book on Japanese grammar. Follow-up [here](https://www.3anet.co.jp/np/books/4682/).
  - [現代日本語文法](https://www.9640.jp/book_view/?475) - A monster 7-volume series on Japanese grammar written by a collective of linguists. Extremely extensive.
  - [庭三郎の現代日本語文法概説](https://djtguide.github.io/grammar/niwasaburoo/index.html) - Another great grammar guide written in Japanese.
  - [国語の文法](https://www.kokugobunpou.com/#gsc.tab=0) - A website discussing grammar as it is taught in Japanese schools.

## Mining

Mining is the process of finding new words in immersion, usually by adding them to Anki via Yomitan.

- Mining setups
  - **[Mining setup guide](https://donkuri.github.io/learn-japanese/mining/)** - A guide to mining along with setups for most common forms of media. Written by [kuri](https://github.com/donkuri/).
  - [Xelieu's mining setup](https://lazyguidejp.github.io/jp-lazy-guide/) - Another setup mining guide. Written by [Xelieu](https://github.com/xelieu).

- Mining templates
  - [Lapis](https://github.com/donkuri/lapis) - A new notetype combining the best of JPMN and JP-study below in a streamlined way that is compatible with many tools. Made by [ruri](https://github.com/bewizible) and [kuri](https://github.com/donkuri).
  - [Senren](https://brenoaqua.github.io/Senren/) - Another new notetype with a very full set of features and a clean-looking UI. Made by [BrenoAqua](https://github.com/BrenoAqua).
  - [jp-mining-note](https://arbyste.github.io/jp-mining-note-prerelease/) - A popular notetype for mining. Very feature-rich. Originally made by [aquafina](https://github.com/Aquafina-water-bottle/), now maintained by [arbyste](https://github.com/arbyste/).
  - [JP-study](https://github.com/rudnam/JP-study) - A collection of templates including a mining template. Made by [rudnam](https://github.com/rudnam).
  - [Crop Theft](https://github.com/Kuuuube/crop-theft) - A more minimalistic but complete mining notetype. Made by [kuuube](https://github.com/Kuuuube).
  - [Vertical Cards](https://github.com/kiwakiwaa/vertical-cards/) - A bit of a different take on Anki notetypes. Allows for vertical content. Made by [kiwakiwaa](https://github.com/kiwakiwaa).

## Immersion

[Immersion](https://learnjapanese.moe/guide/#15-what-even-is-immersion) is the main tool we use to learn the language. See [the mining section](#mining) for an explanation on how to use some of these tools.

- Large frameworks
  - [ッツreader](https://reader.ttsu.app) - An online book reader supporting Yomitan to help you read (light) novels.
  - [asbplayer](https://github.com/killergerbah/asbplayer) - A browser-based media player to allow you to use Yomitan on subtitle files for anime and the like.
  - [Memento](https://github.com/ripose-jp/Memento) - An mpv-based media player meant to help you learn Japanese.
  - [mokuro](https://github.com/kha-white/mokuro) - An OCR made to turn manga into Yomitan-able files. You can also read from [the reader](https://reader.mokuro.app/) or [the catalog](https://catalog.mokuro.moe/).
  - [Agent](https://github.com/0xDC00/agent) - A text hooker to help you use Yomitan with video games.
  - [YomiNinja](https://github.com/matt-m-o/YomiNinja) - A yomitan-compatible OCR to help you extract text from games and the like.
  - [JL](https://github.com/rampaa/JL) - A program that grabs text from the clipboard or a websocket, allowing you to easily mine visual novels and the like.
  - [Mangatan](https://github.com/kaihouguide/Mangatan) - A somewhat involved manga OCR server using Suwayomi, an alternative to Tachiyomi on desktop.
  - [Textractor](https://github.com/Artikash/Textractor) - A text hooker to help you use Yomitan with visual novels. Make sure to get the alpha version by following [this](https://donkuri.github.io/learn-japanese/mining/#textractor).
  - [Game Sentence Miner](https://github.com/bpwhelan/GameSentenceMiner) - Immersion framework on top of Yomitan and a text hooker, made to automate a lot of the Anki card creation process. Written by [Beangate](https://github.com/bpwhelan).
  - [meikipop](https://github.com/rtr46/meikipop) - An OCR popup dictionary. Supports JMdict and doesn't feature mining, but still amazing. Also check out the rest of [rtr46's work](https://github.com/rtr46).
  - [リーダー](https://github.com/21repierre/riidaa/) - An iPad app designed to let you read mokuro'd manga with Yomitan dictionaries.
  - [Jidoujisho](https://github.com/arianneorpilla/jidoujisho) - An immersion framework for mobile devices.
  - [Lumi Reader](https://lumireader.app) *(Beta)* - A fast e-book reader with offline support, reading stats, bookmarks, social features, and Yomitan compatibility.

- Tools
  - **[Jiten](https://jiten.moe/)** - Similar to JPDB, lists media with statistical information about unique words, kanji, etc.
  - [mpvacious](https://github.com/Ajatt-Tools/mpvacious) - A script for mpv made to help you create Anki cards from video with subtitles.
  - [Anacreon's mpv script](https://anacreondjt.gitlab.io/docs/mpvscript/) - Another popular script for mpv to create Anki cards from anime.
  - [Shiori Reader](https://apps.apple.com/us/app/shiori-reader/id6744979827) - An iOS (MacOS maybe supported?) EPUB reader with look-up functionality. Compatible with many Yomitan dictionaries.
  - [Yomine](https://github.com/mcgrizzz/Yomine) - Integrates with various other mining frameworks (notably ASBPlayer) to help you mine most effectively, helping you see what to mine instead of just mining everything.
  - [SubPlz](https://github.com/kanjieater/SubPlz) - A subtitle manager to generate, sync and manage subtitle files. Written by [KanjiEater](https://github.com/kanjieater).
  - [mpv-websocket](https://github.com/kuroahna/mpv_websocket) - A tool to open a websocket from mpv to send subtitles to.
  - [jimaku.cc](https://jimaku.cc/) - A website subtitles for anime.
  - [Renji's texthooker-ui](https://github.com/Renji-XD/texthooker-ui) - A great texthooker page using websockets.
  - [Renji's ttu-whispersync](https://github.com/Renji-XD/ttu-whispersync) - Lets you listen to audiobooks with [ッツreader](https://reader.ttsu.app).
  - [exSTATic](https://github.com/KamWithK/exSTATic) - A texthooker page complete with graphs and statistics. Uses websockets.
  - [ShareX](https://getsharex.com/) - Fully-featured screen recording suite that is useful for screenshots and audio recording.
  - [Japanese Text Analyzer](https://sourceforge.net/projects/japanesetextana/) - A rather old (but useful) Windows-only tool to analyze Japanese text.
  - [imajin](https://github.com/YonKuma/imajin.py) - CLI tool to search through EPUBs and mokuro files for words and sentences.

- Tips and tricks
  - **[Thoughts on immersion](https://donkuri.github.io/learn-japanese/immersion/)** - A collection of thoughts on immersion to help people get into it. Written by [kuri](https://github.com/donkuri/).
  - **[How to immerse](https://learnjapanese.moe/guide/#27-how-to-immerse)** - A discussion on immersion and how best to do it. Written by shoui.

- Recommendations
  - **[Japanese media recommendations](https://docs.google.com/spreadsheets/d/1w42HEKEu2AzZg9K7PI0ma9ICmr2qYEKQ9IF4XxFSnQU/edit?gid=1999205540#gid=1999205540)** - A Japanese media recommendation spreadsheet listing various along with a difficulty description. Managed by [kuri](https://github.com/donkuri/).
  - [Japanese recs](https://donkuri.github.io/learn-japanese/recs/) - A page listing media recommendations. Written by [kuri](https://github.com/donkuri).
  - [LearnNatively](https://learnnatively.com/) - Big collection of Japanese media graded by difficulty. Can also be used for logging immersion.

- Logging immersion
  - **[Japanese Immersion Tracker](https://immersion.bremgovi.com/)** - A local, fully-featured immersion tracker for reading. Made by [emi](https://github.com/Bremgovi).
  - [Xelieu's immersion spreadsheet](https://lazyguidejp.github.io/jp-lazy-guide/immersionDataSpreadsheet/) - A spreadsheet made to log your immersion. Made by [Xelieu](https://github.com/xelieu).
  - [ねむい's anime logging spreadsheet](https://docs.google.com/spreadsheets/d/1CJ5rRmQYg6ckm0U56d3R_IIJBfHiEIZgKfBX4J-sXEs/edit?gid=0#gid=0) - A spreadsheet made by ねむい to log your anime immersion.
  - [HoriSan](https://github.com/Flare155/HoriSanBot) - A feature-full Discord bot to log your immersion. Written by [Flare](https://github.com/Flare155).
  - [tadoku](https://github.com/Eroge-Abyss/tadoku) - A fully-featured visual novel tracker. Requires you to build locally.

- Example sentences
  - **[massif.la](https://massif.la/ja)** - A website aggregating a lot of Japanese example sentences.
  - [Nadeshiko](https://nadeshiko.co/) - Online sentence search engine using anime, movies, etc. Provides an API.
  - [Aozora Bunko example sentences](https://kanji.reader.bz/examples/) - Lets you search for example sentences among [青空文庫 works](https://www.aozora.gr.jp/).
  - [Sentence Search](https://sentencesearch.neocities.org/) - A website allowing you to search for Japanese sentences with native audio. The audio itself can be downloaded from [here](https://mega.nz/folder/A7BGBLCC#0bmwb10zeVtoNwFCn4ua4g).

## Listening

Listening is an important component of Japanese immersion.

- Tools
  - [Condenser](https://ercanserteli.com/condenser/) - A tool to make condensed audio from your Japanese immersion. Useful if you want to do passive immersion.
  - [Podcast Republic](https://www.podcastrepublic.net/) - After changing your location to Japan, you can access a last catalog of Japanese podcasts.
  - [SpoonCast](https://www.spooncast.net/jp) - A variety of listening content.
  - [Numbers](https://langpractice.com/japanese) - A tool made to help you recognize and learn numbers in Japanese.
  - [Whisper](https://subtitlewhisper.com/en) - An AI tool made to generate subtitles and transcriptions. Check out [this guide](https://docs.google.com/document/d/1QnJha6dxfjWBvG9yL0rpOWeMsZdGeiyuhO_kuQaNOLs/edit?tab=t.0#heading=h.dbsyiflokebs) for a simple setup.

- Pitch accent
  - **[Strategies for Acquiring Pitch Accent in Japanese](https://www.youtube.com/watch?v=I-dRbTnLmBY)** - A great introduction to Japanese pitch accent.
  - **[kotu.io](https://kotu.io/)** A website made to help you recognize pitch accent. Requires registration but is easy to do. A backup of the website's minimal pairs function is available on [Kuuube's page](https://kuuuube.github.io/minimal-pairs/).
  - [NotOrange's notes on pitch](https://docs.google.com/document/d/1e5DUuDLPKzYnyX9ZZPp2CXLoxk1ZPwH-Q0a0XCQA-Yc/edit?tab=t.0#heading=h.cgsroygtuckp) - NotOrange's notes on Japanese pitch accent.
  - [xythh's resources](https://xythh.github.io/resources) - A collection of resources on learning Japanese pitch accent. Made by [xythh](https://github.com/xythh).
  - [Yudai Sensei](https://www.youtube.com/@yudaisensei2020) - Native Japanese discussing pitch accent and why it matters.
  - [Dogen](https://www.youtube.com/channel/UCSX0NhNdBA-ZnEFkYFzdw4A) - Popular YouTuber often discussing pitch accent.

## Writing

Physically writing kanji is something you may or may not be interested in. Either way, **[it is suggested you already be somewhat proficient in reading first](https://animecards.site/writingjapanese/)** before you attempt to learn how to write kanji.

- [Kanken deck](https://ankiweb.net/shared/info/759825185) - The recommended way to learn how to write kanji after you know how to read decently well. **I suggest using [this redesign of the deck](https://github.com/kiwakiwaa/kanken-anki-template)**.
- [Kankenbros](https://rentry.org/kankenbros) - The place to look at if you're interested in passing the 漢字検定, 'kanji kentei'.
- [Basic Kanji Book 1](https://www.amazon.com/BASIC-KANJI-BOOK-Vol-1-2-C3-A8me-dp-4893589733/dp/4893589733/ref=dp_ob_title_bk) - If you really insist on using a textbook, this is good.
- [Genki-Yoshi](https://github.com/FragozoLeonardo/Genki-Yoshi) - Software to automatically create 原稿用紙 to practice writing kana and kanji.

## Output

Output is concerned with producing Japanese. It's about speaking and writing (not necessarily literally) Japanese.

- **[Learning to output](https://morg.systems/Learning-to-Output)** - A guide on output to help you get started. Written by [Morg](https://morg.systems/3d24ec19).
- [English-Japanese Language Exchange](https://discord.com/invite/NJJCYVD) - A popular Discord server for both Japanese-speaking and English-speaking people looking to converse.
- [Slowly](https://slowly.app/) - A useful app to make Japanese-speaking penpals.
- [HelloTalk](https://www.hellotalk.com/) - A popular language exchange app.
- [italki](https://www.italki.com/) - A website meant to connect you with language tutors, potentially helping you with output.

## Resource aggregators

Resource aggregators are pages that link a variety of Japanese resource, like this one!

- [Kuzuri's resources](https://kuzuri.neocities.org/resources) - The absolutely humongous resource section of Kuzuri's [amazing website](https://kuzuri.neocities.org/).
- [The Moe Way Resources](https://learnjapanese.moe/resources/) - The resources section of The Moe Way.
- [morg.systems](https://morg.systems/) - Tons of information on learning Japanese.
- [GaijinRyman's Resources List](https://github.com/GaijinRyman/JapaneseResources) - GitHub page listing various Japanese-learning resources and the like.
- [Languagegainz Resources](https://docs.google.com/document/d/1EyIKdsFgsakIh568loSanprRbgzZeAiRTNVkDWoY5RI/edit#) An unofficial list of resources from the Languagegainz Discord. Not officially endorsed by Aussieman (the creator of the Discord).
- [Wotaku's Language Section](https://wotaku.wiki/japan/language) - A list of Japanese learning websites and tools.

## Miscellaneaous

This section contains resources that don't quite fit anywhere else.

- [Irocore](https://irocore.com/) - Japanese color dictionary.
- [fontplus.jp](https://fontplus.jp/font-list/hiraminpron-w3) - A website with various Japanese fonts on display.
- [Jigmo フォント](https://kamichikoichi.github.io/jigmo/) - Jigmo is a set of free fonts that is a great fallback for more obscure kanji.
- [Google Fonts](https://fonts.google.com/) - Free fonts, including Japanese ones.
- [Hissatsuwaza](https://hissatuwaza.kill.jp/index.htm) - A dictionary for fighting moves you might see in anime or manga.
- [Locale Emulator](https://github.com/xupefei/Locale-Emulator) - Really cool locale emulator (as the name suggests). Lets you use applications with a Japanese locale without changing your system settings.
- [LE Shortcut Creator](https://github.com/Svintooo/LEShortcutCreator) - Great app that creates shortcuts for applications that will run through Locale Emulator above so you don't need to change your locale to Japanese to use the applications.
- [Free Programming Books JP](https://github.com/EbookFoundation/free-programming-books/blob/main/books/free-programming-books-ja.md) - The Japanese section of the free programming books GitHub repo. Now you can re-learn your favorite programming language in Japanese! *I recommend Clojure.*
